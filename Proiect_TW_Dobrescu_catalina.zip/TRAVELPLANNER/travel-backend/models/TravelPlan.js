const mongoose = require('mongoose');

const DestinationSchema = new mongoose.Schema({
    name: { type: String, required: true },
    description: { type: String, required: true },
    weather: { type: String, default: '' }, // Pentru prognoza meteo
});

const TravelPlanSchema = new mongoose.Schema({
    title: { type: String, required: true },
    destinations: [DestinationSchema], // Relația copil
    createdAt: { type: Date, default: Date.now },
});

const TravelPlan = mongoose.model('TravelPlan', TravelPlanSchema);

module.exports = TravelPlan;
