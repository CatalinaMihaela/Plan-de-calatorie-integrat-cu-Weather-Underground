const sequelize = require('./config/database');
const TravelPlan = require('./models/TravelPlan');
const Destination = require('./models/Destination');

// Sincronizare baza de date
sequelize.sync({ force: true }) // `force: true` recreează baza la fiecare pornire
    .then(() => console.log('Baza de date sincronizată.'))
    .catch((err) => console.error('Eroare la sincronizarea bazei:', err));

// Pornirea serverului Express
const app = express();
app.use(express.json());
app.use('/api/travel', require('./routes/travelRoutes'));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Serverul rulează pe portul ${PORT}`));
