const express = require('express');
const TravelPlan = require('../models/TravelPlan');
const router = express.Router();

// Get toate planurile de călătorie
router.get('/', async (req, res) => {
    try {
        const plans = await TravelPlan.find();
        res.status(200).json(plans);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Adaugă un nou plan de călătorie
router.post('/', async (req, res) => {
    try {
        const newPlan = new TravelPlan(req.body);
        const savedPlan = await newPlan.save();
        res.status(201).json(savedPlan);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

module.exports = router;
