import React, { useEffect, useState } from "react";
import { getTrips, addTrip } from "./api";

function App() {
    const [trips, setTrips] = useState([]);
    const [newTrip, setNewTrip] = useState("");

    // Preia călătoriile la încărcarea paginii
    useEffect(() => {
        getTrips().then(setTrips).catch((error) => console.error("Eroare la încărcarea călătoriilor:", error));
    }, []);

    // Adaugă o nouă călătorie
    const handleAddTrip = async () => {
        if (!newTrip) return;
        const trip = await addTrip({ name: newTrip, startDate: "2024-06-01", endDate: "2024-06-10" });
        setTrips([...trips, trip]);
        setNewTrip("");
    };

    return (
        <div style={{ textAlign: "center", padding: "20px" }}>
            <h1>Planificator de Călătorii</h1>
            <div>
                <input 
                    value={newTrip} 
                    onChange={(e) => setNewTrip(e.target.value)} 
                    placeholder="Nume călătorie" 
                    style={{ padding: "10px", marginRight: "10px" }}
                />
                <button onClick={handleAddTrip} style={{ padding: "10px", cursor: "pointer" }}>
                    Adaugă călătorie
                </button>
            </div>

            <h2>Lista călătoriilor:</h2>
            {trips.length > 0 ? (
                <ul style={{ listStyle: "none", padding: 0 }}>
                    {trips.map((trip) => (
                        <li key={trip.id} style={{ padding: "10px", borderBottom: "1px solid #ccc" }}>
                            {trip.name} ({trip.startDate} - {trip.endDate})
                        </li>
                    ))}
                </ul>
            ) : (
                <p>Nu există călătorii disponibile.</p>
            )}
        </div>
    );
}

export default App;
