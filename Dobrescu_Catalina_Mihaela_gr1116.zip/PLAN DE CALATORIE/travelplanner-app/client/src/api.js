const API_URL = "http://localhost:5000/api";

// Obține toate călătoriile din backend
export const getTrips = async () => {
    try {
        const response = await fetch(`${API_URL}/trips`);
        if (!response.ok) {
            throw new Error("Eroare la preluarea călătoriilor");
        }
        return response.json();
    } catch (error) {
        console.error("Eroare la obținerea călătoriilor:", error);
        return [];
    }
};

// Adaugă o nouă călătorie
export const addTrip = async (trip) => {
    try {
        const response = await fetch(`${API_URL}/trips`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(trip),
        });
        if (!response.ok) {
            throw new Error("Eroare la adăugarea călătoriei");
        }
        return response.json();
    } catch (error) {
        console.error("Eroare la adăugarea călătoriei:", error);
        return null;
    }
};

// Șterge o călătorie după ID
export const deleteTrip = async (tripId) => {
    try {
        const response = await fetch(`${API_URL}/trips/${tripId}`, {
            method: "DELETE",
        });
        if (!response.ok) {
            throw new Error("Eroare la ștergerea călătoriei");
        }
        return response.json();
    } catch (error) {
        console.error("Eroare la ștergerea călătoriei:", error);
        return null;
    }
};

// Actualizează o călătorie
export const updateTrip = async (tripId, updatedTrip) => {
    try {
        const response = await fetch(`${API_URL}/trips/${tripId}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(updatedTrip),
        });
        if (!response.ok) {
            throw new Error("Eroare la actualizarea călătoriei");
        }
        return response.json();
    } catch (error) {
        console.error("Eroare la actualizarea călătoriei:", error);
        return null;
    }
};
