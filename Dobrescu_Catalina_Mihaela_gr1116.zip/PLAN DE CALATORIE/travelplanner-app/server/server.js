const express = require("express");
const cors = require("cors");
const sequelize = require("./sequelize");
const tripRoutes = require("./routes/tripRoutes");
const destinationRoutes = require("./routes/destinationRoutes");

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/trips", tripRoutes);
app.use("/api/destinations", destinationRoutes);

const PORT = process.env.PORT || 5000;
sequelize.sync({ force: false }).then(() => {
    console.log("Baza de date SQLite este sincronizată!");
    app.listen(PORT, () => console.log(`Serverul rulează pe portul ${PORT}`));
});

