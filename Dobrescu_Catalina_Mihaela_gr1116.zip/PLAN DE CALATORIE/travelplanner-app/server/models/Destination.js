const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");
const Trip = require("./Trip");

const Destination = sequelize.define("Destination", {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    city: { type: DataTypes.STRING, allowNull: false },
    country: { type: DataTypes.STRING, allowNull: false },
    tripId: { type: DataTypes.INTEGER, allowNull: false, references: { model: Trip, key: "id" } },
});

// Relație: Un `Trip` poate avea mai multe `Destinations`
Trip.hasMany(Destination, { foreignKey: "tripId", onDelete: "CASCADE" });
Destination.belongsTo(Trip, { foreignKey: "tripId" });

module.exports = Destination;
