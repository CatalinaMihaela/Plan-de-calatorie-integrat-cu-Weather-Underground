const Trip = require("../models/Trip");

// Obține toate călătoriile
exports.getAllTrips = async (req, res) => {
    try {
        const trips = await Trip.findAll();
        res.status(200).json(trips);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Creează o nouă călătorie
exports.createTrip = async (req, res) => {
    try {
        const { name, startDate, endDate } = req.body;
        const newTrip = await Trip.create({ name, startDate, endDate });
        res.status(201).json(newTrip);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
