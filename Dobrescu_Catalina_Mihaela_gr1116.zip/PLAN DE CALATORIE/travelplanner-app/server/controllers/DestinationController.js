const Destination = require("../models/Destination");
const Trip = require("../models/Trip");

// Obține toate destinațiile
exports.getAllDestinations = async (req, res) => {
    try {
        const destinations = await Destination.findAll();
        res.status(200).json(destinations);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Creează o nouă destinație
exports.createDestination = async (req, res) => {
    try {
        const { city, country, tripId } = req.body;
        const trip = await Trip.findByPk(tripId);
        if (!trip) return res.status(404).json({ message: "Trip not found" });

        const newDestination = await Destination.create({ city, country, tripId });
        res.status(201).json(newDestination);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
